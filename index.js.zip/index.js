var request = require("request");
var name;

// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.

exports.handler = function (event, context) {
    try {
        console.log("event.session.application.applicationId=" + event.session.application.applicationId);

        /**
         * Uncomment this if statement and populate with your skill's application ID to
         * prevent someone else from configuring a skill that sends requests to this function.
         */

    // if (event.session.application.applicationId !== "") {
    //     context.fail("Invalid Application ID");
    //  }

        if (event.session.new) {
            onSessionStarted({requestId: event.request.requestId}, event.session);
        }

        if (event.request.type === "LaunchRequest") {
            onLaunch(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "IntentRequest") {
            onIntent(event.request,
                event.session,
                function callback(sessionAttributes, speechletResponse) {
                    context.succeed(buildResponse(sessionAttributes, speechletResponse));
                });
        } else if (event.request.type === "SessionEndedRequest") {
            onSessionEnded(event.request, event.session);
            context.succeed();
        }
    } catch (e) {
        context.fail("Exception: " + e);
    }
};

/**
 * Called when the session starts.
 */
function onSessionStarted(sessionStartedRequest, session) {
    // add any session init logic here
}

/**
 * Called when the user invokes the skill without specifying what they want.
 */
function onLaunch(launchRequest, session, callback) {
    getWelcomeResponse(callback);
}

/**
 * Called when the user specifies an intent for this skill.
 */
function onIntent(intentRequest, session, callback) {

    name = intentRequest.intent.slots.name.value;
    
    var intent = intentRequest.intent;
    var intentName = intentRequest.intent.name;

    // dispatch custom intents to handlers here
	
	/************ change name to intent name ***************/
    if (intentName == "CallHelpIntent") {
        handleCallHelpIntent(intent, session, callback);
    } else {
         throw "Invalid intent";
    }
}

/**
 * Called when the user ends the session.
 * Is not called when the skill returns shouldEndSession=true.
 */
function onSessionEnded(sessionEndedRequest, session) {

}

// ------- Skill specific logic -------

function getWelcomeResponse(callback) {
	/* changes here */
	// you can change this to whatever you want
    var speechOutput = "Hi marc, who do you want the call for help!";

    var reprompt = "Marc? Do you need help? Who do you want the call for help. Inge, Ringo or Both";

    var header = "Calling for help via sms";
	/* end changes */
	
    var shouldEndSession = false;

    var sessionAttributes = {
        "speechOutput" : speechOutput,
        "repromptText" : reprompt
    };

    callback(sessionAttributes, buildSpeechletResponse(header, speechOutput, reprompt, shouldEndSession));

}

/******************************** custome code here *************************/
function handleCallHelpIntent(intent, session, callback) {
	var speechOutput = "We have a error";

	getJSON(function(data){
		if (data != "ERROR") {
			var speechOutput = data;
		}
		callback(session.Attributes, buildSpeechletResponseWithoutCard(speechOutput, "", true));
	});
}

function url(){
	/* changes here */
	// these name have to fit the ones used in the predefind slots !!!!!
	
	// you may have more than xxx people here
	// the phone number is without ++ or the + sign!!!!! so countycode+number
    if (name == 'Inge') {
		// First person
		return "https://api.clockworksms.com/http/send.aspx?key=enter_your_clockworkskeyhere&to=enter_phone_number&content=This+is+a+messages+from+Alexa++Marc+needs+help+asap.";
    }else if (name == 'Ringo') {
		// second person
		return "https://api.clockworksms.com/http/send.aspx?key=enter_your_clockworkskeyhere&to=enter_phone_number&content=This+is+a+messages+from+Alexa++Marc+needs+help+asap.";
    }else if (name == 'Both') {
		// send to both
		return "https://api.clockworksms.com/http/send.aspx?key=enter_your_clockworkskeyhere&to=enter_first_phone_number&to=enter_seconf_phone_number&content=This+is+a+messages+from+Alexa++Marc+needs+help+asap.";        
    }
	/* end changes */
}

function getJSON(callback){
	
	// making the request
	
	/* change here */
	if (name == 'Inge' || name == 'Ringo' || name == 'Both') {
	    request.get(url(),function(error,response,body){
		    /*var obj = JSON.parse(body);
		
		    var bookingnr = obj.bookingnr;
		    var startdate = obj.startdate;
		    var enddate = obj.enddate;
		    var property = obj.property;
		    */
		    var result = 'Sms was send. to ' + name;        
		
		    callback(result);
	    });
	}else{
	    var result = 'No Sms send. Name not in list.';
	    callback(result);
	}
	
}

// ------- Helper functions to build responses for Alexa -------


function buildSpeechletResponse(title, output, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: "PlainText",
            text: output
        },
        card: {
            type: "Simple",
            title: title,
            content: output
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: repromptText
            }
        },
        shouldEndSession: shouldEndSession
    };
}

function buildSpeechletResponseWithoutCard(output, repromptText, shouldEndSession) {
    return {
        outputSpeech: {
            type: "PlainText",
            text: output
        },
        reprompt: {
            outputSpeech: {
                type: "PlainText",
                text: repromptText
            }
        },
        shouldEndSession: shouldEndSession
    };
}

function buildResponse(sessionAttributes, speechletResponse) {
    return {
        version: "1.0",
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    };
}

function capitalizeFirst(s) {
    return s.charAt(0).toUpperCase() + s.slice(1);
}

